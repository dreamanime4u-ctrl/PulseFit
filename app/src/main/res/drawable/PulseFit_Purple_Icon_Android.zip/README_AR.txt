حزمة أيقونة PulseFit البنفسجية

انسخ مجلد app الموجود هنا إلى مشروعك مع دمج الملفات داخل app/src/main/res.
لا تستبدل مجلد res كاملاً؛ ادمج المجلدات والملفات فقط.

في app/src/main/AndroidManifest.xml تأكد من وجود السطرين داخل وسم application:
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher"

ثم نفّذ بناء APK من GitHub Actions.
